﻿using System;
using System.Collections.Generic;
using TugasPolyDanColl2907.ClassAnak;
using TugasPolyDanColl2907.ClassInduk;

namespace TugasPolyDanColl2907
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Tugas Pertemuan 11 Polymorphism Dan Collection";

            KaryawanTetap karyawanTetap = new KaryawanTetap();
            karyawanTetap.Nik = "77771111";
            karyawanTetap.Nama = "Leon da Silva";
            karyawanTetap.GajiBulanan = 20000000;

            KaryawanHarian karyawanHarian = new KaryawanHarian();
            karyawanHarian.Nik = "88882222";
            karyawanHarian.Nama = "Villa da Silva";
            karyawanHarian.JumlahJamKerja = 5;
            karyawanHarian.UpahPerJam = 20000;

            Sales sales = new Sales();
            sales.Nik = "88772211";
            sales.Nama = "Ace da Silva";
            sales.JumlahPenjualan = 50;
            sales.Komisi = 100000;

            List<Karyawan> listKaryawan = new List<Karyawan>();

            listKaryawan.Add(karyawanTetap);
            listKaryawan.Add(karyawanHarian);
            listKaryawan.Add(sales);

            int noUrut = 1;

            foreach (Karyawan karyawan in listKaryawan)
            {
                Console.WriteLine("{0}. Nik : {1}, Nama : {2}, Gaji : Rp.{3 : 0}", noUrut, karyawan.Nik, karyawan.Nama, karyawan.Gaji());

                noUrut++;

            }

            Console.ReadKey();

        }
    }
}
    