﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProjectApkPulsa.ClassInduk
{
    public abstract class PembelianPulsa
    {
        public int NoAntrian { get; set; }
        public string Nama { get; set; }
        public string NoHP { get; set; }
        public string Operator { get; set; }
        public double JumlahPembelian { get; set; }
        public abstract double Harga();
    }
}
