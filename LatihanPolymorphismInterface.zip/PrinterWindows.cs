﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LatihanPolymorphismInterface2907
{
    public interface PrinterWindows
    {
        void Show()
        {
        }
        void Print()
        {
        }
    }
}
