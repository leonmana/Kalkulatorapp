﻿using System;

public class PrinterWindows
{

    public virtual void Show()
    {
        Console.WriteLine("Sony display dimension : 10*11");
    }
    public virtual void Print()
    {
        Console.WriteLine("Sony Printer is Printing ...");
    }

}