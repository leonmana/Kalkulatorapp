﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstraction.Interface
{
    public class Mouse : IHardwareKomputer
    {
        public void Fungsi()
        {
            Console.WriteLine("Mouse berfungsi untuk mengatur pergerakan kursor secara cepat ");
            Console.WriteLine("Dan untuk memberikan suatu perintah dengan hanya menekan tombol pada mouse komputer");
        }
    }
}
