﻿using System;
//using Abstraction.AbstractClass;
using Abstraction.Interface;


namespace Abstraction
{
    class Program
    {
        static void Main(string[] args)
        {
            /*HardwareKomputer hardwareKomputer;

            hardwareKomputer = new Mouse();
            hardwareKomputer.Fungsi();

            Console.WriteLine();
            hardwareKomputer = new Keyboard();
            hardwareKomputer.Fungsi();*/

            IHardwareKomputer hardwareKomputer;

            hardwareKomputer = new Mouse();
            hardwareKomputer.Fungsi();

            Console.WriteLine();
            hardwareKomputer = new Keyboard();
            hardwareKomputer.Fungsi();


            Console.ReadKey();
        }
    }
}
