﻿using FinalProjectApkPulsa.ClassInduk;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace FinalProjectApkPulsa.ClassAnak
{
    public class Smartfrend : PembelianPulsa
    {
        public override Double Harga()
        {
            return JumlahPembelian + 1000;
        }
    }
}
