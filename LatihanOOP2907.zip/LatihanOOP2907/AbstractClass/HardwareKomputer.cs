﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstraction.AbstractClass
{
    public abstract class HardwareKomputer
    {
        public abstract void Fungsi();
    }
}
