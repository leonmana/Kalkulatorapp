﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LatihanPolymorphismInterface2907
{
   public class LaserJet : PrinterWindows
    {
        public void show()
        {
            Console.WriteLine("LaserJet display dimension : 12*12");
        }
        public void Print()
        {
            Console.WriteLine("LaserJet printer printing.....");
        }
    }
}
