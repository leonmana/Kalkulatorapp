﻿using System;
using System.Collections.Generic;
using PolyAndCollectPart2.ClassAnak;
using PolyAndCollectPart2.ClassInduk;


namespace PolyAndCollectPart2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<KaryawanTetap> karyawantetap = new List<KaryawanTetap>();
            List<KaryawanHarian> karyawanharian = new List<KaryawanHarian>();
            List<Sales> sales = new List<Sales>();

        menu:
            Console.WriteLine("1.Masukkan Data Karyawan");
            Console.WriteLine("2.Check Data Karyawan");
            Console.WriteLine("3.Hapus Data Karyawan");
            Console.WriteLine("4.Keluar");
            Console.WriteLine();
            Console.Write(" Pilih 1-4 : ");


            int pilihaninput;
            int pilih;
            pilihaninput = int.Parse(Console.ReadLine());

            if (pilihaninput == 1)
            {
                Console.WriteLine("1.Masukkan Data Karyawan Tetap");
                Console.WriteLine("2.Masukkan Data Karyawan Harian");
                Console.WriteLine("3.Masukkan Data Sales");
                Console.WriteLine();
                Console.Write("Pilih 1-3 : ");

                pilih = Convert.ToInt32(Console.ReadLine());

                if (pilih == 1)
                {
                    string nik, nama;
                    double gajibulanan;
                    Console.WriteLine("Masukan NIK : ");
                    nik = Console.ReadLine();
                    Console.WriteLine("Masukan Nama : ");
                    nama = Console.ReadLine();
                    Console.WriteLine("Masukan Gaji Bulanan : ");
                    gajibulanan = int.Parse(Console.ReadLine());

                    karyawantetap.Add(new KaryawanTetap() { Nik = nik, Nama = nama, GajiBulanan = gajibulanan });
                }

                else if (pilih == 2)
                {
                    string nik, nama;
                    double jam;
                    double upah;
                    Console.WriteLine("Masukan NIK : ");
                    nik = Console.ReadLine();
                    Console.WriteLine("Masukan Nama : ");
                    nama = Console.ReadLine();
                    Console.WriteLine("Masukan Jumlah Jam : ");
                    jam = int.Parse(Console.ReadLine());
                    Console.WriteLine("Masukan Jumlah Upah : ");
                    upah = int.Parse(Console.ReadLine());

                    karyawanharian.Add(new KaryawanHarian() { Nik = nik, Nama = nama, JumlahJamKerja = jam, UpahPerJam = upah });
                }

                else if (pilih == 3)
                {
                    string nik, nama;
                    double jual;
                    double komisi;
                    Console.WriteLine("Masukan NIK : ");
                    nik = Console.ReadLine();
                    Console.WriteLine("Masukan Nama : ");
                    nama = Console.ReadLine();
                    Console.WriteLine("Masukan Jumlah Penjualan : ");
                    jual = int.Parse(Console.ReadLine());
                    Console.WriteLine("Masukan Komisi : ");
                    komisi = int.Parse(Console.ReadLine());

                    sales.Add(new Sales() { Nik = nik, Nama = nama, JumlahPenjualan = jual, Komisi = komisi });
                }
                Console.WriteLine("Tekan Enter Untuk Lanjut");
                Console.ReadKey(true);
                Console.Clear();
                goto menu;
            }

            else if (pilihaninput == 2)
            {
                Console.WriteLine("Data Karyawan");
                Console.WriteLine();
                int no = 1;
                foreach (Karyawan karyawan in karyawantetap)
                {
                    Console.WriteLine("{0}. Nik : {1}, Nama : {2}, Gaji : {3}, Karyawan Tetap",
                    no, karyawan.Nik, karyawan.Nama, karyawan.Gaji());
                    no++;
                }

                foreach (Karyawan karyawan in karyawanharian)
                {
                    Console.WriteLine("{0}. Nik : {1}, Nama : {2}, Gaji : {3}, Karyawan Harian",
                    no, karyawan.Nik, karyawan.Nama, karyawan.Gaji());
                    no++;
                }

                foreach (Karyawan karyawan in sales)
                {
                    Console.WriteLine("{0}. Nik : {1}, Nama : {2}, Gaji : {3}, Sales",
                    no, karyawan.Nik, karyawan.Nama, karyawan.Gaji());
                    no++;
                }

                Console.WriteLine("Tekan Enter Untuk Lanjut");
                Console.ReadKey(true);
                Console.Clear();
                goto menu;
            }
            else if (pilihaninput == 3)
            {
                Console.WriteLine("Hapus Karyawan");
                Console.WriteLine();
                string hapus;
                Console.WriteLine("Masukan NIK yang ingin dihapus : ");
                hapus = Console.ReadLine();
                int i = 0;
                foreach (Karyawan karyawan in karyawantetap)
                {
                    if (hapus == karyawan.Nik)
                    {
                        karyawantetap.RemoveAt(i);
                        break;
                    }
                    i++;
                }
                i = 0;
                foreach (Karyawan karyawan in karyawanharian)
                {
                    if (hapus == karyawan.Nik)
                    {
                        karyawanharian.RemoveAt(i);
                        break;
                    }
                    i++;
                }
                i = 0;
                foreach (Karyawan karyawan in sales)
                {
                    if (hapus == karyawan.Nik)
                    {
                        sales.RemoveAt(i);
                        break;
                    }
                    i++;
                }
                Console.WriteLine("Data Berhasil dihapus");
                Console.WriteLine("Tekan Enter Untuk Lanjut");
                Console.ReadKey(true);
                Console.Clear();
                goto menu;
            }

            else
            {
                Console.WriteLine("Terima Kasih");
            }

            Console.ReadKey(true);
            Console.Clear();
        }
    }
}
