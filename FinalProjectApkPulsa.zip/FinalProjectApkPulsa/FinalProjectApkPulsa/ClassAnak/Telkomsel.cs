﻿using FinalProjectApkPulsa.ClassInduk;
using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProjectApkPulsa.ClassAnak
{
    public class Telkomsel : PembelianPulsa
    {
        public override Double Harga()
        {
            return JumlahPembelian + 1000;
        }
    }
}
