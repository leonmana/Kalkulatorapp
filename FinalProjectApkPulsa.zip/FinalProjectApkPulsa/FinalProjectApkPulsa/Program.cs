﻿using FinalProjectApkPulsa.ClassAnak;
using FinalProjectApkPulsa.ClassInduk;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;

namespace FinalProjectApkPulsa
{
    class Program
    {
        static List<PembelianPulsa> listPulsa = new List<PembelianPulsa>();
        static List<Telkomsel> listTelkomsel = new List<Telkomsel>();
        static List<Indosat> listIndosat = new List<Indosat>();
        static List<XL> listXL = new List<XL>();
        static List<Smartfrend> listSmartfrend = new List<Smartfrend>();
        static void Main(string[] args)
        {
            int no = 0;
            Console.WriteLine("|----------------------------------------------------|");
            Console.WriteLine("|~~~~~SELAMAT DATANG DI APLIKASI PEMBELIAN PULSA~~~~~|");
            Console.WriteLine("|~~~~~==========BUWONG PUYOH CELLULER===========~~~~~|");
            Console.WriteLine("|----------------------------------------------------|");
            Console.WriteLine();
            Console.WriteLine("Ingin beli Pulsa tetapi takut keluar rumah karena Corona?");
            Console.WriteLine("Buwong Puyoh Celluler solunsinya :D");

        menu:

            Console.Clear();
            Console.WriteLine(">>>> MENU <<<<");
            Console.WriteLine("1. Beli Pulsa");
            Console.WriteLine("2. Riyawat Pembelian");
            Console.WriteLine("3. Hapus Pembelian");
            Console.WriteLine("4. Ubah Data Pembelian");
            Console.WriteLine("5. Keluar");
            Console.WriteLine();
            Console.Write("Masukkan pilihan (1-5) : ");
            int pilMenu = Convert.ToInt32(Console.ReadLine());

            switch (pilMenu)
            {
                case 1:
                    no++;
                    BeliPulsa(no);
                    goto menu;
                    break;
                case 2:
                    RiwayatPembelian();
                    goto menu;
                    break;
                case 3:
                    HapusPembelian();
                    goto menu;
                    break;
                case 4:
                    UbahDataPembelian();
                    goto menu;
                    break;
                case 5:
                    return;

                default:
                    break;
            }
        }

        static void BeliPulsa(int no)
        {

        data:

            Console.Clear();
            Console.WriteLine("==== Jenis Operator Pulsa ====");
            Console.WriteLine("1. Telkomsel");
            Console.WriteLine("2. Indosat");
            Console.WriteLine("3. XL");
            Console.WriteLine("4. Smartfrend");
            Console.WriteLine("===============================");
            Console.Write("Pilih : ");
            int pilJenis = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("===============================");


            Console.WriteLine("No Antrian\t\t : {0}", no);
            Console.Write("Nama\t\t : ");
            string nama = (Console.ReadLine());
            Console.Write("No HP\t\t : ");
            string nohandphone = (Console.ReadLine());
       
            Console.Write("Jumlah Pembelian\t : ");
            double jumlahbeli = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("===============================");
            
            if (pilJenis == 1)
            {
                string jenisoperator = "Telkomsel";
                listPulsa.Add(new Telkomsel { NoAntrian = no, Nama = nama, NoHP = nohandphone, JumlahPembelian = jumlahbeli, Operator = jenisoperator }); ;
            }
            if (pilJenis == 2)
            {
                string jenisoperator = "Indosat";
                listPulsa.Add(new Indosat { NoAntrian = no, Nama = nama, NoHP = nohandphone,  JumlahPembelian = jumlahbeli, Operator = jenisoperator }); ;
            }
            if (pilJenis == 3)
            {
                string jenisoperator = "XL";
                listPulsa.Add(new XL { NoAntrian = no, Nama = nama, NoHP = nohandphone, JumlahPembelian = jumlahbeli, Operator = jenisoperator }); ;
            }
            if (pilJenis == 4)
            {
                string jenisoperator = "Smartfrend";
                listPulsa.Add(new Smartfrend { NoAntrian = no, Nama = nama, NoHP = nohandphone,  JumlahPembelian = jumlahbeli, Operator = jenisoperator }); ;
            }

            if (pilJenis != 1 && pilJenis != 2 && pilJenis != 3 && pilJenis != 4)
            {
                Console.WriteLine("Pilihan tidak tersedia");
                Console.WriteLine();
                Console.WriteLine("tekan ENTER untuk memilih ulang");
                Console.ReadKey(true);
                goto data;
            }



            Console.WriteLine("Tekan ENTER untuk kembali ke menu");
            Console.ReadKey(true);

        }

        static void RiwayatPembelian()
        {
            Console.Clear();
            Console.WriteLine("===== Riwayat Pembelian =====");
            Console.WriteLine();
            int no = 0;

            foreach (PembelianPulsa belipulsa in listPulsa)
            {
                no++;
                Console.WriteLine("List ke {0}", no);
                Console.WriteLine("No Antrian\t : {0}", belipulsa.NoAntrian);
                Console.WriteLine("Operator\t : {0}", belipulsa.Operator);
                Console.WriteLine("Nama\t\t : {0}", belipulsa.Nama);
                Console.WriteLine("NoHP\t\t : {0}", belipulsa.NoHP);
                Console.WriteLine("Harga\t\t : Rp.{0}", belipulsa.Harga());
                Console.WriteLine("================================");

            }
            if (no == 0)
            {
                Console.WriteLine("Tidak ada pembelian");
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("tekan ENTER untuk kembali ke menu");
            Console.ReadKey(true);
        }

        static void HapusPembelian()
        {
            Console.Clear();
            Console.WriteLine("=====Hapus Pembelian=====");
            Console.WriteLine();
            Console.WriteLine("Masukkan No Antrian yang ingin di hapus : ");
            int hapus = int.Parse(Console.ReadLine());
            int i = 0;
            bool ketemu = false;

            foreach (PembelianPulsa belipulsa in listPulsa)
            {
                if (hapus == belipulsa.NoAntrian)
                {
                    listPulsa.RemoveAt(i);
                    ketemu = true;
                    Console.WriteLine("Data Berhasil di hapus");
                    break;
                }
                i++;
            }
            if (ketemu == false)
            {
                Console.WriteLine("Data tidak di temukan");
            }
            Console.WriteLine("tekan ENTER untuk kembali ke menu");
            Console.ReadKey(true);
        }
        static void UbahDataPembelian()
        {
            Console.WriteLine("=====Ubah data Pembeli=====");
            Console.WriteLine();
            Console.WriteLine("Masukkan No Antrian : ");
            int ubah = int.Parse(Console.ReadLine());
            Console.WriteLine();
            int i = 0;
            bool ketemu = false;

            foreach (PembelianPulsa belipulsa in listPulsa)
            {
                if (ubah == belipulsa.NoAntrian)
                {
              
                    Console.WriteLine("No Antrian\t : {0}", belipulsa.NoAntrian);
                    Console.WriteLine("Operator\t : {0}", belipulsa.Operator);
                    Console.WriteLine("Nama\t\t : {0}", belipulsa.Nama);
                    Console.WriteLine("NoHP\t\t : {0}", belipulsa.NoHP);
                    Console.WriteLine("Harga\t\t : {0}", belipulsa.Harga());
                    Console.WriteLine("================================");

                    Console.Write("Nama\t\t : ");
                    string nama = (Console.ReadLine());
                    Console.Write("No HP\t\t : ");
                    string nohandphone = (Console.ReadLine());

                    belipulsa.Nama = nama;
                    belipulsa.NoHP = nohandphone;

                    ketemu = true;
                    break;
                }
                i++;
            }
            if (ketemu == false)
            {
                Console.WriteLine();
                Console.WriteLine("data tidak di temukan");
            }

            Console.WriteLine("tekan ENTER untuk kembali ke menu");
            Console.ReadKey();
        }
    }
}